/*
  Comando 'se-entao-senao' com impressao
  Helena Caseli
  2010
*/

#include <stdio.h>
#include <stdlib.h>

int main() {
	if (4 == 3) {
		printf("4 eh igual a 3");
	}
	else {
		printf("4 eh diferente de 3");
	}
	return 0;
}
