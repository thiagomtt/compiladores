/*
  Declaracao de funcao com impressao
  Helena Caseli
  2010
*/

#include <stdio.h>
#include <stdlib.h>

int dobro(int x) {
	return 2*x;
}

int main() {
	printf("%d",dobro(4));
	return 0;
}
